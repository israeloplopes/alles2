<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
    <div class="recent-items-wp notika-shadow sm-res-mg-t-30">
        <div class="rc-it-ltd">
            <div class="recent-items-ctn">
                <div class="recent-items-title">
                    <h2>Últimas Vendas</h2>
                </div>
            </div>
            <div class="recent-items-inn">
                <table class="table table-inner table-vmiddle">
                    <thead>
                        <tr>
                            <th>id.</th>
                            <th>Prod.</th>
                            <th style="width: 60px">Venda</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="f-500 c-cyan">4555</td>
                            <td>Samsung Galaxy Mega</td>
                            <td class="f-500 c-cyan">$921</td>
                        </tr>
                        <tr>
                            <td class="f-500 c-cyan">4556</td>
                            <td>Huawei Ascend P6</td>
                            <td class="f-500 c-cyan">$240</td>
                        </tr>
                        <tr>
                            <td class="f-500 c-cyan">8778</td>
                            <td>HTC One M8</td>
                            <td class="f-500 c-cyan">$400</td>
                        </tr>
                        <tr>
                            <td class="f-500 c-cyan">5667</td>
                            <td>Samsung Galaxy Alpha</td>
                            <td class="f-500 c-cyan">$870</td>
                        </tr>
                        <tr>
                            <td class="f-500 c-cyan">7886</td>
                            <td>LG G3</td>
                            <td class="f-500 c-cyan">$790</td>
                        </tr>
                    </tbody>
                </table>
            </div>
<div id="recent-items-chart" class="flot-chart-items flot-chart vt-ct-it tb-rc-it-res"></div>
        </div>
    </div>
</div>
