<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
    <div class="statistic-right-area notika-shadow mg-tb-30 sm-res-mg-t-0">
        <div class="past-day-statis">
            <h2>Análise Global</h2>
            <p>Amostragem de Produtos x Vendas.</p>
        </div>
<div class="dash-widget-visits"></div>
        <div class="past-statistic-an">
            <div class="past-statistic-ctn">
                <h3><span class="counter">3,20,000</span></h3>
                <p>Custo Médio</p>
            </div>
            <div class="past-statistic-graph">
                <div class="stats-bar"></div>
            </div>
        </div>
        <div class="past-statistic-an">
            <div class="past-statistic-ctn">
                <h3><span class="counter">1,03,000</span></h3>
                <p>Markup</p>
            </div>
            <div class="past-statistic-graph">
                <div class="stats-line"></div>
            </div>
        </div>
        <div class="past-statistic-an">
            <div class="past-statistic-ctn">
                <h3><span class="counter">24,00,000</span></h3>
                <p>ROI</p>
            </div>
            <div class="past-statistic-graph">
                <div class="stats-bar-2"></div>
            </div>
        </div>
    </div>
</div>
